
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Exception"],["c","Sesser\\Scurl\\Exceptions\\RequestException"],["c","Sesser\\Scurl\\Request"],["c","Sesser\\Scurl\\Response"],["c","Sesser\\Scurl\\Scurl"],["c","Sesser\\Scurl\\Utils"]];
